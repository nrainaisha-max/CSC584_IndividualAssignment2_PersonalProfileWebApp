package com.yourpackage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProfileListServlet")
public class ProfileListServlet extends HttpServlet {

    private static final String JDBC_URL =
            "jdbc:derby://localhost:1527/PersonalProfileWebAppDB;create=true";
    private static final String JDBC_USERNAME = "app";
    private static final String JDBC_PASSWORD = "app";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String keyword = req.getParameter("keyword"); // search name / studentId
        String filter = req.getParameter("filter");   // filter program / hobby

        List<Profile> profiles = new ArrayList<>();

        StringBuilder sql = new StringBuilder(
                "SELECT * FROM PersonalProfiles WHERE 1=1"
        );

        // 🔍 Search by Name or Student ID
        if (keyword != null && !keyword.trim().isEmpty()) {
            sql.append(" AND (LOWER(name) LIKE ? OR LOWER(studentId) LIKE ?)");
        }

        // 🎯 Filter by Programme or Hobby
        if (filter != null && !filter.trim().isEmpty()) {
            sql.append(" AND (LOWER(program) LIKE ? OR LOWER(hobbies) LIKE ?)");
        }

        try (Connection conn = DriverManager.getConnection(
                    JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int index = 1;

            if (keyword != null && !keyword.trim().isEmpty()) {
                ps.setString(index++, "%" + keyword.toLowerCase() + "%");
                ps.setString(index++, "%" + keyword.toLowerCase() + "%");
            }

            if (filter != null && !filter.trim().isEmpty()) {
                ps.setString(index++, "%" + filter.toLowerCase() + "%");
                ps.setString(index++, "%" + filter.toLowerCase() + "%");
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Profile p = new Profile(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("studentId"),
                        rs.getString("program"),
                        rs.getString("email"),
                        rs.getString("hobbies"),
                        rs.getString("intro")
                );
                profiles.add(p);
            }

            req.setAttribute("profiles", profiles);
            req.getRequestDispatcher("profileList.jsp").forward(req, resp);

        } catch (SQLException e) {
            throw new ServletException("Database error while retrieving profiles", e);
        }
    }
}
