package com.yourpackage;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {

    private static final String JDBC_URL = "jdbc:derby://localhost:1527/PersonalProfileWebAppDB;create=true";
    private static final String JDBC_USERNAME = "app";
    private static final String JDBC_PASSWORD = "app";

    private static final String INSERT_PROFILE_SQL =
            "INSERT INTO PersonalProfiles (name, studentId, program, email, hobbies, intro) VALUES (?, ?, ?, ?, ?, ?)";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String studentId = req.getParameter("studentId");
        String program = req.getParameter("program");
        String email = req.getParameter("email");
        String hobbies = req.getParameter("hobbies");
        String intro = req.getParameter("intro");

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement ps = conn.prepareStatement(INSERT_PROFILE_SQL)) {

            ps.setString(1, name);
            ps.setString(2, studentId);
            ps.setString(3, program);
            ps.setString(4, email);
            ps.setString(5, hobbies);
            ps.setString(6, intro);

            ps.executeUpdate();
            resp.sendRedirect("success.html");

        } catch (SQLException e) {
            e.printStackTrace();
            resp.getWriter().println("Error: " + e.getMessage());
        }
    }
}
