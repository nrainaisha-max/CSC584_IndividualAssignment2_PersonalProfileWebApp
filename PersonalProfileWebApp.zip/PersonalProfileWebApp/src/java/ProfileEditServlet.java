package com.yourpackage;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProfileEditServlet")
public class ProfileEditServlet extends HttpServlet {

    private static final String JDBC_URL =
        "jdbc:derby://localhost:1527/PersonalProfileWebAppDB;create=true";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASS = "app";

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        int id = Integer.parseInt(req.getParameter("id"));

        try (Connection c = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement ps =
                 c.prepareStatement("SELECT * FROM PersonalProfiles WHERE id=?")) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                req.setAttribute("profile", new Profile(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("studentId"),
                    rs.getString("program"),
                    rs.getString("email"),
                    rs.getString("hobbies"),
                    rs.getString("intro")
                ));
                req.getRequestDispatcher("profileEdit.jsp").forward(req, resp);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        try (Connection c = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement ps = c.prepareStatement(
                 "UPDATE PersonalProfiles SET name=?, studentId=?, program=?, email=?, hobbies=?, intro=? WHERE id=?")) {

            ps.setString(1, req.getParameter("name"));
            ps.setString(2, req.getParameter("studentId"));
            ps.setString(3, req.getParameter("program"));
            ps.setString(4, req.getParameter("email"));
            ps.setString(5, req.getParameter("hobbies"));
            ps.setString(6, req.getParameter("intro"));
            ps.setInt(7, Integer.parseInt(req.getParameter("id")));

            ps.executeUpdate();
            resp.sendRedirect("ProfileListServlet");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
