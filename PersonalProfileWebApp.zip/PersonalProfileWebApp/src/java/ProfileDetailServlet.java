package com.yourpackage;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProfileDetailServlet")
public class ProfileDetailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Same database connection as ProfileListServlet
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/PersonalProfileWebAppDB;create=true";
    private static final String JDBC_USERNAME = "app";
    private static final String JDBC_PASSWORD = "app";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        int id = Integer.parseInt(idParam);
        Profile selectedProfile = null;

        String query = "SELECT * FROM PersonalProfiles WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    selectedProfile = new Profile(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("studentId"),
                            rs.getString("program"),
                            rs.getString("email"),
                            rs.getString("hobbies"),
                            rs.getString("intro")
                    );
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Set the profile in request attribute
        request.setAttribute("profile", selectedProfile);

        // Forward to JSP
        request.getRequestDispatcher("profileDetail.jsp").forward(request, response);
    }
}
