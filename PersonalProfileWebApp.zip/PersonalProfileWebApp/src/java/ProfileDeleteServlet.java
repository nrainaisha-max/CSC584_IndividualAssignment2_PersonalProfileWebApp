package com.yourpackage;

import java.io.IOException;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ProfileDeleteServlet")
public class ProfileDeleteServlet extends HttpServlet {

    private static final String JDBC_URL =
        "jdbc:derby://localhost:1527/PersonalProfileWebAppDB;create=true";
    private static final String JDBC_USER = "app";
    private static final String JDBC_PASS = "app";

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {

        int id = Integer.parseInt(req.getParameter("id"));

        try (Connection c = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASS);
             PreparedStatement ps =
                 c.prepareStatement("DELETE FROM PersonalProfiles WHERE id=?")) {

            ps.setInt(1, id);
            ps.executeUpdate();
            resp.sendRedirect("ProfileListServlet");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
