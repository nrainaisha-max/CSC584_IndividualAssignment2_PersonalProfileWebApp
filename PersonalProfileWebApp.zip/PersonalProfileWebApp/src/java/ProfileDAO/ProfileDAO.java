package com.yourpackage;

import java.sql.*;
import java.util.*;

public class ProfileDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/your_db";
    private String jdbcUser = "root";
    private String jdbcPass = "";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
    }

    // 🔹 Get all / Search / Filter
    public List<Profile> getProfiles(String keyword, String filter) {
        List<Profile> list = new ArrayList<>();
        String sql = "SELECT * FROM profile WHERE 1=1";

        if (keyword != null && !keyword.isEmpty()) {
            sql += " AND (name LIKE ? OR student_id LIKE ?)";
        }
        if (filter != null && !filter.isEmpty()) {
            sql += " AND (program LIKE ? OR hobbies LIKE ?)";
        }

        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            int index = 1;
            if (keyword != null && !keyword.isEmpty()) {
                ps.setString(index++, "%" + keyword + "%");
                ps.setString(index++, "%" + keyword + "%");
            }
            if (filter != null && !filter.isEmpty()) {
                ps.setString(index++, "%" + filter + "%");
                ps.setString(index++, "%" + filter + "%");
            }

            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(extract(rs));

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    // 🔹 Get by ID
    public Profile getById(int id) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM profile WHERE id=?")) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return extract(rs);

        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // ✏️ Update
    public void update(Profile p) {
        String sql = "UPDATE profile SET name=?, student_id=?, program=?, email=?, hobbies=?, intro=? WHERE id=?";
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, p.getName());
            ps.setString(2, p.getStudentId());
            ps.setString(3, p.getProgram());
            ps.setString(4, p.getEmail());
            ps.setString(5, p.getHobbies());
            ps.setString(6, p.getIntro());
            ps.setInt(7, p.getId());
            ps.executeUpdate();

        } catch (Exception e) { e.printStackTrace(); }
    }

    // 🗑️ Delete
    public void delete(int id) {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM profile WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private Profile extract(ResultSet rs) throws SQLException {
        Profile p = new Profile();
        p.setId(rs.getInt("id"));
        p.setName(rs.getString("name"));
        p.setStudentId(rs.getString("student_id"));
        p.setProgram(rs.getString("program"));
        p.setEmail(rs.getString("email"));
        p.setHobbies(rs.getString("hobbies"));
        p.setIntro(rs.getString("intro"));
        return p;
    }
}
